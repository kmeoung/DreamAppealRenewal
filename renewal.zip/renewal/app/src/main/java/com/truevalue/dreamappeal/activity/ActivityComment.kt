package com.truevalue.dreamappeal.activity

import com.truevalue.dreamappeal.base.BaseActivity

class ActivityComment : BaseActivity(){

}