package com.truevalue.dreamappeal.utils

import com.truevalue.dreamappeal.BuildConfig

class Comm_Param{
    companion object {
        val REAL = !BuildConfig.DEBUG
        val APP_NAME = "DreamAppeal"

    }
}