package com.truevalue.dreamappeal.activity

import android.os.Bundle
import com.truevalue.dreamappeal.base.BaseActivity

class ActivitySearch : BaseActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }
}