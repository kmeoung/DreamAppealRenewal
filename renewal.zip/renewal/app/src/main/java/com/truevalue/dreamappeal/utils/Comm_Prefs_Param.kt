package com.truevalue.dreamappeal.utils

class Comm_Prefs_Param {

    companion object{
        val PREFS_IS_LOGIN = "PREFS_IS_LOGIN"
    }

}